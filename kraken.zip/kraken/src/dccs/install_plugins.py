# -*- coding: utf-8 -*-

import shutil

def install_maya():
    userPref = "./maya_connector/userSetup.py"
    localPath = "C:/Users/<username>/Documents/maya/<version>/scripts"
    shutil.copyfile(userPref, localPath)

def install_blender():
    pass

def install_houdini():
    pass

def install_nuke():
    pass

def install_unreal():
    pass

def check_installs():
    pass
