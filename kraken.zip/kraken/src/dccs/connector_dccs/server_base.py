# -*- coding: utf-8 -*-

import json

from PySide2 import QtCore
from PySide2 import QtNetwork


# subclass JSONEncoder
# created because in Blender there was an issue
# with the call json.dumps(reply)
# TypeError: Object of type set is not JSON serializable
# So we need to define a custom call that convert obj in a list.
class setEncoder(json.JSONEncoder):
    def default(self, obj):
        return list(obj)


class ServerBase(QtCore.QObject):

    PORT = 17344
    HEADER_SIZE = 10

    def __init__(self, port,  parent):
        super(ServerBase, self).__init__(parent)

        self.port = port if port else self.__class__.PORT
        self._msg_status = ""

        self.initialize()

    def initialize(self):
        self.server = QtNetwork.QTcpServer(self)
        self.server.newConnection.connect(self.establish_connection)

        if self.listen():
            self._msg_status = "Server listening on port: {0}".format(self.port)
            print("[LOG] {}".format(self._msg_status))
        else:
            self._msg_status = "Server initialization failed"
            print("[ERROR] {}".format(self._msg_status))

    def listen(self):
        if not self.server.isListening():
            return self.server.listen(QtNetwork.QHostAddress.LocalHost, self.port)

        return False

    def establish_connection(self):
        self.socket = self.server.nextPendingConnection()
        if self.socket.state() == QtNetwork.QTcpSocket.ConnectedState:
            self.socket.disconnected.connect(self.on_disconnected)
            self.socket.readyRead.connect(self.read)

            print("[LOG] Connection Established")

    def on_disconnected(self):
        self.socket.disconnected.disconnect()
        self.socket.readyRead.disconnect()

        self.socket.deleteLater()

        print("[LOG] Connection Disconnected")

    def read(self):
        """
        read message from client
        :return:
        """
        bytes_remaining = -1
        json_data = ""

        while self.socket.bytesAvailable():
            # Header
            if bytes_remaining <= 0:
                byte_array = self.socket.read(self.__class__.HEADER_SIZE)
                bytes_remaining, valid = byte_array.toInt()

                if not valid:
                    bytes_remaining = -1
                    self.write_error("Invalid Header")

                    # purge unknown data
                    self.socket.readAll()
                    return

            # Body
            if bytes_remaining > 0:
                byte_array = self.socket.read(bytes_remaining)
                bytes_remaining -= len(byte_array)
                json_data += byte_array.data().decode()

                if bytes_remaining == 0:
                    bytes_remaining = -1

                    data = json.loads(json_data)
                    self.process_data(data)

                    json_data = ""

    def write(self, reply):
        """
        send reply to client
        :param reply: (dict)
        :return: no return
        """
        json_reply = json.dumps(reply, cls=setEncoder)

        if self.socket.state() == QtNetwork.QTcpSocket.ConnectedState:
            header = "{0}".format(len(json_reply.encode())).zfill(self.__class__.HEADER_SIZE)

            data = QtCore.QByteArray("{0}{1}".format(header, json_reply).encode())

            self.socket.write(data)

    def write_error(self, error_msg):
        reply = {
            "success": False,
            "msg": error_msg,
            "cmd": "unknown"
        }

        self.write(reply)

    def process_data(self, data):
        reply = {
            "success": False
        }

        cmd = data["cmd"]
        if cmd == "ping":
            reply["success"] = True

        else:
            self.process_cmd(cmd, data, reply)

            if not reply["success"]:
                reply["cmd"] = cmd
                if "msg" not in reply.keys():
                    reply["msg"] = "Unknown Error"

        self.write(reply)

    def process_cmd(self, cmd, data, reply):
        reply["msg"] = "Invalid command ({0})".format(cmd)


    def get_msg_status(self):
        return self._msg_status
