#################################################################################################################


INSTALLATION:
(documentation: https://support.foundry.com/hc/en-us/articles/360003811839-Q100490-What-are-the-init-py-and-menu-py-files)

1. Copy the content of the "menu.py" file in your menu.py file inside your nuke startup script location.
   Nuke searches for startup scripts in any path listed in the Nuke plug-in path. The default Nuke 14.0v5 plug-in paths are as follows:

	WINDOWS:

	'C:\Users\<userName>\.nuke'
	'C:\Program Files\Common Files\Nuke\14.0\plugins',
	'C:\Program Files\Nuke14.0v5\plugins\user'
	'C:\Program Files\Nuke14.0v5\plugins\caravr'
	'C:\Program Files\Nuke14.0v5\plugins\air'
	'C:\Program Files\Nuke14.0v5\plugins\icons'
	'C:\Program Files\Nuke14.0v5\plugins'

	LINUX:

	'/home/<userName>/.nuke'
	'/usr/local/Nuke/14.0/plugins'
	'/usr/local/Nuke14.0v5/plugins/user'
	'/usr/local/Nuke14.0v5/plugins/caravr'
	'/usr/local/Nuke14.0v5/plugins/air'
	'/usr/local/Nuke14.0v5/plugins/icons'
	'/usr/local/Nuke14.0v5/plugins'

	MACOS:

	'/Users/<userName>/.nuke'
	'/Library/Application Support/Nuke/14.0/plugins'
	'/Applications/Nuke14.0v5/Nuke14.0v5.app/Contents/MacOS/plugins/user' 
	'/Applications/Nuke14.0v5/Nuke14.0v5.app/Contents/MacOS/plugins/caravr' 
	'/Applications/Nuke14.0v5/Nuke14.0v5.app/Contents/MacOS/plugins/air' 
	'/Applications/Nuke14.0v5/Nuke14.0v5.app/Contents/MacOS/plugins/icons' 
	'/Applications/Nuke14.0v5/Nuke14.0v5.app/Contents/MacOS/plugins'

	The current set of plug-in paths Nuke is using can be found by running the below command in the Script Editor: print(nuke.pluginPath())
	
	Nuke scans for startup scripts in the reverse order of how they are listed, so from the lists above, Nuke14.0v5/plugins is scanned first, and <userName>/.nuke is scanned last.

	Other paths can also be added to this list by either using the nuke.pluginAddPath() to add paths to the beginning of the list, or nuke.pluginAppendPath() to add 
	paths to the end of the list. The plug-in path list can also be edited by modifying the NUKE_PATH environment variable.


#################################################################################################################


"nuke_command_port.py"
It is the DCC connector that run the server and open the port inside the dcc.


#################################################################################################################


"menu.py"
Note:
The menu.py file is called anytime a GUI version of Nuke is launched, NO for terminal only sessions of Nuke

It is the file that creates the menu and you need to copy it inside Startup script locations folder,
or add the conte of this "menu.py" inside your already menu.py file.



#################################################################################################################


"nuke_client.py"
It is the client that set the connection with dcc and send commands to the dcc and run some operation.
For example, open new file, save new file, etc. etc.


#################################################################################################################
