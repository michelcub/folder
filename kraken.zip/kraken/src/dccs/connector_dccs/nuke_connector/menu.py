import nuke

command_str = "import sys;sys.path.insert(0, \"/home/francesco.surace/Desktop/test_conn\");import nuke_command_port;nuke_command_port.main()"

menu_bar = nuke.menu('Nuke')
m = menu_bar.addMenu('&PipelinePro')
m.addCommand('&Command Port', command_str)