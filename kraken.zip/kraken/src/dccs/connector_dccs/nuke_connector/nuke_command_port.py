# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/21
"""

import os
import sys
# sys.path.insert(0, "C:/python/python37/Lib/site-packages")
# sys.path.insert(0, "C:/Users/frasu/Downloads/pipelinepro_connector_dccs")

virtualenv = 'C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Hydra/venv_hydra_pyqt/'
virtualenv_lib = virtualenv + 'Lib/site-packages'
sys.path.insert(0, virtualenv_lib)
sys.path.insert(0, "C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Hydra/hydra/src/dccs/connector_dccs")

from PySide2 import QtWidgets, QtCore, QtGui

from server_base import ServerBase

import nuke


class CommandPortWindow(QtWidgets.QDialog):

    def __init__(self, parent):
        super(CommandPortWindow, self).__init__(parent)

        self.server = NukeServer(parent=parent)

        # init ui
        self.init_ui()
        self.setup_ui()

        # Close pop-up after 2 seconds (2000 ms)
        QtCore.QTimer.singleShot(2000, self.close)

    def init_ui(self):

        main_layout = QtWidgets.QVBoxLayout()

        # create logo image
        logo_pixmap = QtGui.QPixmap("{}/{}".format(
            "C:/Users/frasu/Downloads/pipelinepro_connector_dccs",
            "pipeline_pro_logo.png"
        ))
        self.logo_image = QtWidgets.QLabel()
        self.logo_image.setPixmap(logo_pixmap)
        self.logo_image.setFixedSize(logo_pixmap.size().width(),
                                     logo_pixmap.size().height())
        self.logo_image.setAlignment(QtCore.Qt.AlignCenter)

        # create label for connection status
        self.connection_status = QtWidgets.QLabel()
        self.connection_status.setAlignment(QtCore.Qt.AlignCenter)
        self.connection_status.setStyleSheet("color: rgb(255, 255, 255);"
                                            "font-weight: thin;"
                                            "font-size:16px")

        main_layout.addWidget(self.logo_image)
        main_layout.addWidget(self.connection_status)

        self.setLayout(main_layout)
        self.setFixedSize(400, 200)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint |
                            QtCore.Qt.WindowStaysOnTopHint |
                            QtCore.Qt.Dialog)
        self.setWindowOpacity(1)
        self.setStyleSheet("background-color: rgb(25, 35, 45);")
        self.center_window_position()
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)

    def setup_ui(self):
        try:
            self.connection_status.setText(self.server.get_msg_status())
        except Exception as e:
            print("{}".format(str(e)))

    def center_window_position(self):
        """
        center window on screen
        :return:
        """
        qr = self.frameGeometry()
        cp = QtGui.QGuiApplication.primaryScreen().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())


class NukeServer(ServerBase):

    PORT = 17563

    def __init__(self, parent):
        super(NukeServer, self).__init__(parent)

    def process_cmd(self, cmd, data, reply):
        if cmd == "open":
            self.open(data, reply)
        elif cmd == "save":
            self.save(data, reply)
        else:
            super(NukeServer, self).process_cmd(cmd, data, reply)

    def open(self, data, reply):
        file_path = data["file_path"]

        result = nuke.scriptOpen(file_path)

        reply["result"] = result
        reply["success"] = True

    def save(self, data, reply):
        """
        save file. If new_file flag is True, save new file.
        """
        file_path = data["file_path"]
        is_new_file = data["new_file"]
        file_type = data["file_type"]

        result = None

        # if not a new file version, force to same file name
        current_nuke_file_name = None
        try:
            current_nuke_file_name = nuke.scriptName()
        except Exception as e:
            print(e)

        if not is_new_file:

            if current_nuke_file_name:
                file_path = current_nuke_file_name
            
            result = nuke.scriptSave(file_path)
        else:
            result = nuke.scriptSaveAs(file_path)

        reply["result"] = result
        reply["success"] = True


def main():
    window = CommandPortWindow(parent=QtWidgets.QApplication.activeWindow())
    window.show()
