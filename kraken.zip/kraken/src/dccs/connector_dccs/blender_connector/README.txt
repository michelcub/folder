#################################################################################################################


INSTALLATION:

Automatic Installation from Blender:
1. Open Blender
2. Open Edit > Preferences > Addons window
3. Install "blender_connector.zip" as a new addon from the Install button (the file is inside addon folder)


Manual Installation:
Inside your blender's addons folder:
For example, in WINDOWS should be:
    C:\Users\<username>\AppData\Roaming\Blender Foundation\Blender\<version>\scripts\addons

1. create a new folder with this name: "blender_connector"

2. inside the folder just created ("blender_connector"), copy these two files:
 - "__init__.py"
 - "blender_command_port.py"



#################################################################################################################


"blender_command_port.py"
It is the DCC connector that run the server and open the port inside the dcc.


#################################################################################################################


"__init__.py"
It is the File that you need for creating menu and generating operaotr inside blender that menu will execute.
Also, contains information for the addon. You can install it as normal addon.


#################################################################################################################


"blender_client.py"
It is the client that set the connection with dcc and send commands to the dcc and run some operation.
For example, open new file, save new file, etc. etc.


#################################################################################################################
