# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/21
"""

bl_info = {
	"name": "PipelinePro Addons",
	"author": "PipelinePro Software S.L.",
	"version": (1, 0, 0),
	"blender": (2, 80, 0),
	"description": "Blender Connector with PipelinePro Platform",
	"category": "Development"
}

from importlib import reload
from . import blender_command_port
import bpy


class PipelineProMainMenu(bpy.types.Menu):
    bl_label = "PipelinePro"
    bl_idname = "OBJECT_MT_pipelinepro"

    def __init__(self):
        print("PipelinePro Main Menu Loaded")

    def draw(self, context):
        layout = self.layout

        layout.operator("pipelinepro.command_port")


classes = [
	
	blender_command_port.CommandPortOp,
	PipelineProMainMenu,
]


def draw_item(self, context):
    layout = self.layout
    layout.menu(PipelineProMainMenu.bl_idname)


def register():
	reload(blender_command_port)

	for cl in classes:
		bpy.utils.register_class(cl)

	bpy.types.TOPBAR_MT_editor_menus.append(draw_item)


def unregister():
	for cl in classes:
		bpy.utils.unregister_class(cl)

	bpy.types.TOPBAR_MT_editor_menus.remove(draw_item)


if __name__ == "__main__":
	register()