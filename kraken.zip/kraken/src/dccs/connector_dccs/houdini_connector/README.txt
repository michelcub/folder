#################################################################################################################


INSTALLATION:

1. Copy "MainMenuCommon.xml" in your Houdini Documents folder.
   For example, in WINDOWS should be:
   		C:\Users\<username>\Documents\houdini19.5


#################################################################################################################


"houdini_command_port.py"
It is the DCC connector that run the server and open the port inside the dcc.


#################################################################################################################


"MainMenuCommon.xml"
It is the file that creates the menu and you need to copy it inside $HOUDINI_USER_PREF_DIR folder.
For example, in windows the $HOUDINI_USER_PREF_DIR is pointing to: C:\Users\<username>\Documents\houdini19.5


#################################################################################################################


"houdini_client.py"
It is the client that set the connection with dcc and send commands to the dcc and run some operation.
For example, open new file, save new file, etc. etc.


#################################################################################################################
