import maya.cmds as cmds
import maya.mel as mel


def create_pipelinepro_menu(menu_name):
    """
    PipelinePro Main Menu
    """
    if cmds.about(batch=True):
        # don't create menu in batch mode
        return

    # destroy any pre-existing pipelinepro menu
    if cmds.menu("PipelineProMenu", exists=True):
        cmds.deleteUI("PipelineProMenu")

    # crerate root item
    sg_menu = cmds.menu(
        "PipelineProMenu",
        label=menu_name,
        # Get the mel global variable value for main window.
        # In order to get the global variable in mel.eval we have to assign it to another temporary value
        # so that it returns the result.
        parent=mel.eval("$retvalue = $gMainWindow;")
    )

    # create Command Port Item
    cmds.menuItem(
        label="Command Port",
        parent=sg_menu,
        command="import importlib; import sys; sys.path.insert(0, \"C:/Users/frasu/Downloads/pipelinepro_connector_dccs/maya_connector\");import maya_command_port;importlib.reload(maya_command_port);maya_command_port.main();",
    )



if __name__ == "__main__":
    create_pipelinepro_menu(menu_name="PipelinePro")