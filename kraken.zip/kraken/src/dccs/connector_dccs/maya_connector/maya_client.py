# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/21
"""

import sys
sys.path.insert(0, "C:/Users/frasu/Downloads/pipelinepro_connector_dccs")

from client_base import ClientBase


class MayaClient(ClientBase):

    PORT = 17559

    def open(self, file_path, force=True):
        cmd = {
            "cmd": "open",
            "file_path": file_path,
            "force": force
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

    def save(self, file_path, force=True, is_new_file=False, file_type="mayaAscii"):
        cmd = {
            "cmd": "save",
            "file_path": file_path,
            "force": force,
            "new_file": is_new_file,
            "file_type": file_type
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None


if __name__ == "__main__":

    file_path = "C:/Users/frasu/Desktop/sphere.ma"

    maya_client = MayaClient(timeout=120)
    if maya_client.connect():
        print("Connected successfully.")

        # open
        result = maya_client.open(file_path)
        if result:
            print("File opened successfully: '{0}'".format(result))


        # file_path = "C:/Users/frasu/Desktop/cube.ma"
        # # save same file
        # result = maya_client.save(file_path)
        # print(result)
        # if result:
        #     print("File saved successfully: '{0}'".format(result))

        # save as new version
        #new_file_path = "C:/Users/frasu/Desktop/sphere_2.ma"
        #result = maya_client.save(new_file_path, is_new_file=True)
        #if result:
        #    print("File saved successfully: '{0}'".format(result))

        if maya_client.disconnect():
            print("Disconnected successfully")

    else:
        print("Failed to connect")
