import sys

sys.path.insert(0, "C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/Hydra/hydra/src/dccs/connector_dccs/maya_connector")
import create_main_menu

import maya.cmds as cmds

cmds.evalDeferred("create_main_menu.create_pipelinepro_menu(menu_name='PipelinePro')")
