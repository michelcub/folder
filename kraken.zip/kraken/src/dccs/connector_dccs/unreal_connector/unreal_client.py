# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/21
"""

import sys
sys.path.insert(0, "C:/Users/frasu/Downloads/pipelinepro_connector_dccs")

from client_base import ClientBase


class UnrealClient(ClientBase):

    PORT = 17562

    def open(self, file_path):
        cmd = {
            "cmd": "open",
            "file_path": file_path,
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

    def save(self, file_path, is_new_file=False, file_type="uproject"):
        cmd = {
            "cmd": "save",
            "file_path": file_path,
            "new_file": is_new_file,
            "file_type": file_type
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None


if __name__ == "__main__":

    file_path = "C:/Users/frasu/Desktop/sphere.uproject"

    unreal_client = UnrealClient(timeout=120)
    
    if unreal_client.connect():
        print("Connected successfully.")

        filename = "C:/Users/frasu/Documents/Unreal Projects/MyProject/MyProject.uproject"

        # open
        # result = unreal_client.open(file_path)
        # if result:
        #     print("File opened successfully: '{0}'".format(result))


        # file_path = "C:/Users/frasu/Desktop/cube.ma"
        # # save same file
        # result = unreal_client.save(file_path)
        # print(result)
        # if result:
        #     print("File saved successfully: '{0}'".format(result))

        # save as new version
        #new_file_path = "C:/Users/frasu/Desktop/sphere_2.ma"
        #result = unreal_client.save(new_file_path, is_new_file=True)
        #if result:
        #    print("File saved successfully: '{0}'".format(result))

        if unreal_client.disconnect():
            print("Disconnected successfully")

    else:
        print("Failed to connect")
