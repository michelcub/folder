# -*- coding: utf-8 -*-

import src.pipelinepro.settings as settings
from .ingestador import obtener_informacion_ruta
import os
import json

from src.operations.download import Download
from src.api.graphql import api_call
from src.dccs.maya_client_api import MayaClient
import src.pipelinepro.settings as settings

def open_folder(path):
    # TODO: Comprobar que path es una folder para evitar ataques
    folder_to_server(path)
    command = 'start ' + path
    os.system(command)

    return True


def download_folder(kraken, key):
    down = Download(kraken)
    folder_list = key.split()
    down.download_folder_list(folder_list)
    return True


def open_file(kraken, key):
    url = kraken.http_url
    query = '''
          query {
              file(token: "{token}",
                    key:"{key}") {
                key
                fileExtension
                fileLocal
                link
              }
            }
        '''
    query = query.replace('{key}', key)
    response = api_call(kraken, url, query=query)
    response = json.loads(response)
    link = response['data']['file']['link']
    fileLocal = response['data']['file']['fileLocal']

    # If file dont exists download.
    # TODO: Hacer comparacion de version, fecha o tamaño.
    if not os.path.exists(fileLocal):
        down = Download(kraken)
        down.download_file(link, fileLocal)

    extension = response['data']['file']['fileExtension']
    extension = extension.replace('.', '')
    if extension in settings.EXTENSION_MAYA:
        maya = MayaClient()
        maya.open(fileLocal)
    elif extension in settings.EXTENSION_BLENDER:
        exe = '"C:/Users/medinilla/Dropbox/_Original/_Portables/blender/blender.exe"'
        command = exe + ' ' + fileLocal
        os.system(command)
        pass

    return fileLocal


def folder_to_server(dst_Folder):
    """
    Crea las carpetas si no estan ahi
    """
    if os.path.isdir(dst_Folder):
        return True
    else:
        os.makedirs(dst_Folder)
        return True


def frompath_tojson(self, path):
    data_json = obtener_informacion_ruta(path)
    if self.ws:
        self.ws.send(json.dumps({
            "message": {
                "type": "frompath_tojson",
                "data": data_json
            }
        }))
    else:
        print("WebSocket connection not established. Unable to send data.")