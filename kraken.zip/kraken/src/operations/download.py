# -*- coding: utf-8 -*-

from PyQt5.QtCore import QObject, pyqtSignal


import requests
import json
import os

from src.api.graphql import api_call, loging

class Download(QObject):
    # print_console_download = pyqtSignal(str)
    def __init__(self, kraken):
        self.kraken = kraken
        self.url = kraken.http_url
        self.username = kraken.username
        self.password = kraken.password
        if not kraken.token_auth:
            kraken.token_auth = loging(self, self.url)
        self.token_auth = kraken.token_auth

    def download_task_list(self, task_list):
        for task_key in task_list:
            folder_list = self.depencence_files(task_key)
            # print(folder_list)
            for folder in folder_list:
                # print(folder)
                folder_target = folder['files']
                for file in folder_target:
                    print(file['fileLocal'])
                    self.order_file(file)
            print('---------------------------------------')


    def depencence_folders(self, key):
        query_folder = '''
              query {
                  task(token: "{token}",
                        key:"{key}") {
                    dependenceTree {
                      key
                    }
                  }
                }
            '''
        query_folder = query_folder.replace('{key}', key)
        folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
        folder_response = json.loads(folder_response)
        file_list = folder_response['data']['task']['dependenceTree']

        return file_list

    def depencence_files(self, key):
        query_files = '''
              query {
                  task(token: "{token}",
                        key:"{key}") {
                    dependenceTree {
                      files {
                        fileName
                        fileSize
                        fileLocal
                        link
                      }
                    }
                  }
                }
            '''
        query_files = query_files.replace('{key}', key)
        folder_response = api_call(self.kraken, self.url, query=query_files, token=self.token_auth)
        folder_response = json.loads(folder_response)
        file_list = folder_response['data']['task']['dependenceTree']

        return file_list

    def folder_files(self, key):
        query_folder = '''
              query {
                folder(token: "{token}",
                        key:"{key}") {
                  name
                  folderLocal
                  files {
                      fileName
                      fileSize
                      fileLocal
                      link
                    }
                }
              }
            '''
        query_folder = query_folder.replace('{key}', key)

        folder_response = api_call(self.kraken, self.url, query=query_folder, token=self.token_auth)
        folder_response = json.loads(folder_response)
        folderLocal = folder_response['data']['folder']['folderLocal']
        file_list = folder_response['data']['folder']['files']

        return folderLocal, file_list

    def order_file(self, file):
        file_path = file['fileLocal']
        folder_path = os.path.dirname(file_path)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # Si el fichero no existe lo copia
        if not os.path.exists(file_path):
            self.download_file(file['link'], file_path)
        else:
            file_size = os.path.getsize(file_path)
            # if file_size != file['fileSize']:
            #     print(' from ', file_size, ' >> ', file['fileSize'])
            #     print('--- Sobreescribo ---')
            #     self.download_file(file['link'], file_path)
            # else:
            #     print(file['fileName'], '--- It´s correct ---')
        return file_path

    def download_file(self, file_link, file_path):
        response = requests.get(file_link)
        with open(file_path, 'wb') as archivo:
            archivo.write(response.content)
            # poner metadatos del original
            # self.print_console_download.emit('    Download', file_path)
            print('    Download', file_path)
        return file_path


    def detect_new_files(self, folderLocal, file_list):
        # Mira si hay ficheros en folderLocal(local) que no estan en file_list(cloud) para poder subirlos
        file_list_folder = os.listdir(folderLocal)
        file_list_cloud = []
        for file_object in file_list:
            valor_deseado = file_object.get("fileName")
            file_list_cloud.append(valor_deseado)

        file_list_local = []
        for lf in file_list_folder:
            if os.path.isfile(folderLocal + lf):
                file_list_local.append(lf)

        new_files = [archivo for archivo in file_list_local if archivo not in file_list_cloud]
        return new_files


    def download_folder_list(self, folder_list):
        for folder_key in folder_list:
            folderLocal, file_list = self.folder_files(folder_key)

            new_files = self.detect_new_files(folderLocal, file_list)
            if new_files:
                print('    detected new filer for upload:')
                for new in new_files:
                    print(folderLocal + new)

            for file in file_list:
                self.order_file(file)
            print('---------------------------------------')




