# -*- coding: utf-8 -*-

import asyncio
import websockets
import json


async def connect():
    # url = f"wss://localhost:8000/ws/some_url/ "  # Cambiar la URL según tu configuración
    url = f"wss://188.166.202.85/ws/some_url/ "  # Cambiar la URL según tu configuración
    url = f"wss://staging.pipelinepro.io/ws/some_url/ "  # Cambiar la URL según tu configuración
    async with websockets.connect(url) as websocket:

        message_input = input("Enter a message: ")

        data = {
            "message": message_input
        }

        json_data = json.dumps(data)

        await websocket.send(json_data)
        response = await websocket.recv()
        print(f"Response: {response}")

asyncio.get_event_loop().run_until_complete(connect())




