# -*- coding: utf-8 -*-

from PyQt5 import QtCore, QtWidgets
from PyQt5.uic import loadUi

import src.pipelinepro.settings as settings

import subprocess
import base64
import os

from src.libraries.file_encryp import save_disk, load_disk, encrypt, deencrypt
from src.ui.windows_control import WindowControl

class SettingsWindow(QtWidgets.QDialog, WindowControl):
    def __init__(self, kraken):
        super(SettingsWindow, self).__init__()

        program_path = str(os.getcwd())
        program_path = program_path.replace('\\', '/')

        loadUi("{}/src/ui/settings.ui".format(program_path), self)
        self.kraken = kraken

        # Captura de Clicks de botones
        self.button_logout.clicked.connect(self.print_hola)
        self.button_save_settings.clicked.connect(self.print_hola)

        self.button_close.clicked.connect(self.close_app)

        # Quitar titulo
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setWindowOpacity(1)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # SizeGrip
        self.gripSize = 10
        self.grip = QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize, self.gripSize)

        # Captura del Click - mover ventana
        self.frame_top.mouseMoveEvent = self.mover_ventana

        self.file_disk = program_path + settings.CACHE_FILE

        # DCCs
        self.open_maya.clicked.connect(self.open_dcc_maya)



    def open_dcc_maya(self):
        software_path = self.exe_path_maya.text()
        print(software_path)

        # software_path = "C:\Program Files\Autodesk\Maya2020\bin\maya.exe"
        python_script = "create_main_menu.py"
        encoded_python = base64.b64encode(python_script.encode('utf-8'))
        # use exec cmd instead of execfile cmd for python 3 or >
        script_text = '''python("import base64; exec(open(base64.urlsafe_b64decode({})).read())")'''
        # command arguments
        args = [
            software_path,
            "-command",
            script_text.format(encoded_python)
        ]
        # run batch process and hide all output that are not logged by the tool
        # (for example, maya batch output line)
        subprocess.check_output(args, stderr=subprocess.STDOUT)

    def print_hola(self):
        print('hola')

    def close_app(self):
        self.close()

"""
Grabar todos los settings en el cache del usuario para reutilizarlos para cualquira
Estas configuraciones son de la maquina, por lo que se pueden reciclar

"""
