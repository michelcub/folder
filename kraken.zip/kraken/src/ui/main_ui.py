# -*- coding: utf-8 -*-

from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtCore import QPropertyAnimation, QEasingCurve, QUrl, Qt
from PyQt5 import QtCore, QtWidgets
from PyQt5.uic import loadUi
from PyQt5.QtWebEngineWidgets import QWebEngineView

import threading
import os
import random
import requests
import json

import src.pipelinepro.settings as settings

from src.ui.settings_window import SettingsWindow
from src.ui.windows_control import WindowControl
from src.libraries.file_encryp import save_disk, load_disk, encrypt, deencrypt, write_cache_file
from src.api.graphql import api_call
# from src.operations.download import Download


class MainWindow(QMainWindow, WindowControl):
    def __init__(self, kraken):
        super(MainWindow, self).__init__()

        # Conector de mensajes
        self.kraken = kraken
        self.kraken.print_console_ws.connect(self.print_console)
        # Download.print_console_download.connect(self.print_console)

        self.log_console = []

        program_path = str(os.getcwd())
        program_path = program_path.replace('\\', '/')

        loadUi("{}/src/ui/kraken.ui".format(program_path), self)
        self.apiKey = None

        # Iniciamos Connect Contraido
        # self.frame_loginPannel.show()
        self.frame_connect.show()
        self.frame_login_status.hide()

        # Sin loging no hay settings
        # self.button_settings.hide()

        self.webapp_ready = False
        if self.webapp_ready:
            self.load_webapp(self)


        # Captura de Clicks de botones
        self.button_send.clicked.connect(self.login_action)

        # Captura de Clicks de allways on top
        self.button_pin.clicked.connect(self.toggle_always_on_top)

        # self.button_settings.clicked.connect(self.insert_log)
        self.button_settings.clicked.connect(self.open_settings)
        self.button_close.clicked.connect(self.close_app)
        # self.button_close.clicked.connect(self.close_app)
        # self.button_close.clicked.connect(self.close)

        # Quitar titulo
        self.setWindowFlag(QtCore.Qt.FramelessWindowHint)
        self.setWindowOpacity(1)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)

        # SizeGrip
        self.gripSize = 10
        self.grip = QtWidgets.QSizeGrip(self)
        self.grip.resize(self.gripSize, self.gripSize)

        # Captura del Click - mover ventana
        self.frame_top.mouseMoveEvent = self.mover_ventana
        self.frame_top.mouseDoubleClickEvent = self.vista_normal

        self.file_disk = program_path + settings.CACHE_FILE


    def load_webapp(self, token_auth):
        print('load')
        self.web_layout = QWebEngineView()
        url = self.kraken.http_url + settings.ENDPOINT_WEBAPP
        self.web_layout.setUrl(QUrl(url))
        self.main_layout.addWidget(self.web_layout)


    def open_settings(self):
        self.settings_window = SettingsWindow(self.kraken)
        self.settings_window.show()

    def close_app(self):
        # TODO: Poner la opcion de que al cerrar manda al Systray como hacer Prism (coger ese código)
        # TODO: Coseguir que cierre bien cuando se le ordena
        try:
            if self.kraken.ws:
                self.kraken.ws.close()
            if self.kraken.t_ws:
                self.kraken.t_ws.join()

            # hilos_activos = threading.enumerate()
            # for thr in hilos_activos:
            #     print(thr)

            # print('   Active Threads:', threading.active_count())
            # pid = self.kraken.t_ws.native_id
            # os.kill(pid, 9)

            # print('   Active Threads:', threading.active_count())
            # pid = self.kraken.get_ident()
            # subprocess.run(["taskkill", "/F", "/PID", str(pid)])
            # os.kill(pid, signal.SIGTERM) # 15
            # os.kill(pid, signal.SIGKILL) # 9
            # os.kill(pid, 9) # 9

        except Exception as e:
            # print(e)
            print('Close')
            pass
        self.close()

    def insert_log(self):
        amount = threading.active_count()
        value = random.randint(1, 999999)
        menssage = 'Th ' + str(amount) + ' --- ' + str(value)
        self.print_console(menssage)

    def print_console(self, menssage):
        self.log_console.insert(0, str(menssage))
        s = '\n'.join([str(n) for n in self.log_console])
        self.textBrowser.setText(s)

    def login_action(self):
        """
        Proceso de transformacion de los input de login en las variables transformadas del objeto kraken
        TODO: Llevarlo a una libreria separada con las llamadas
        """
        pmt_url = self.input_url.text()
        user = self.input_user.text()
        password = self.input_password.text()
        apiKey = self.input_apiKey.text()

        if pmt_url:
            pmt_url = pmt_url.rstrip('/')
            self.kraken.http_url = pmt_url.rstrip('/')
            ws_url = self.kraken.http_url.replace('https://', '')
            self.kraken.ws_url = ws_url.replace('http://', '')

        if pmt_url and apiKey:
            if not apiKey or len(apiKey) < 35:
                print('   apikey no valida')
            else:
                print('   Login por apiKey')
                self.kraken.apiKey = apiKey

                # try:
                self.kraken.userKey = apiKey # ws_room
                self.print_console('Server Connected')
                self.label_urlconnected.setText(self.kraken.http_url)
                self.kraken.connect_ws()

                self.frame_connect.hide()
                self.frame_view.hide()

                self.textBrowser.setFixedHeight(700)

                # except:
                #     self.print_console('Login Fail')
            # TODO: --- Hacer que el login pueda ser por token o por credenciales

        elif pmt_url and user and password:
            self.kraken.username = user
            self.kraken.password = password

            # TODO: Si el servidor al que apunta está muerto no arranca
            try:
                self.kraken.token_auth, self.kraken.userKey = self.login(pmt_url, user, password)
            except:
                self.print_console('Login Fail')
            if self.kraken.userKey:
                # print('Up webapp with', self.kraken.userKey)
                self.frame_core.setFixedHeight(150)
                self.load_webapp(self.kraken.userKey)  # ws_room
                self.frame_connect.hide()
                self.frame_login_status.show()

                self.print_console('Cache file readed')
                write_cache_file(self.file_disk, pmt_url, user, password)

                # print('Up WS with', self.kraken.userKey)
                self.kraken.connect_ws()

                self.label_urlconnected.setText(self.kraken.http_url)


    def login(self, pmt_url, username, password):
        query_token = f'''
              mutation {{
                tokenAuth(username: "{username}", password: "{password}") {{
                  token
                }}
              }}
            '''
        response = requests.post(pmt_url + '/graphql/', json={'query': query_token})
        response_token = response.text
        response_token = json.loads(response_token)
        token_auth = response_token['data']['tokenAuth']['token']
        print(token_auth)
        userKey = self.userKeyAuth(token_auth)
        print(userKey)
        return token_auth, userKey


    def userKeyAuth(self, token):
        query = '''
              query {
                  userKeyAuth(token: "{token}")
                }
            '''
        response = api_call(self.kraken, self.kraken.http_url, query, token)
        response = json.loads(response)
        userKey = response['data']['userKeyAuth']
        room = userKey
        return userKey


    def toggle_always_on_top(self):
        if self.windowFlags() & Qt.WindowStaysOnTopHint:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowStaysOnTopHint)
        else:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        self.show()