# -*- coding: utf-8 -*-

from PyQt5.QtCore import QObject, pyqtSignal

import threading
import os

import src.pipelinepro.settings as settings

from src.ui.main_ui import MainWindow
from src.api.web_socket import WS_comunications
from src.libraries.file_encryp import read_cache_file


class Kraken(QObject, WS_comunications):
    print_console_ws = pyqtSignal(str)

    def __init__(self):
        super(Kraken, self).__init__()
        self.ui = MainWindow(self)
        self.version = '2023.2.1'
        self.userKey = None

        program_path = str(os.getcwd())
        program_path = program_path.replace('\\', '/')

        self.file_disk = program_path + settings.CACHE_FILE
        if os.path.exists(self.file_disk):
            try:
                pmt_url, http_url, ws_url, user, password = read_cache_file(self.file_disk)
                self.load_cache(pmt_url, http_url, ws_url, user, password)
            except Exception as e:
                print(f"Ocurrió un error al leer el archivo de caché: {e}")
        else:
            print('Archivo de caché no existe.')

    def connect_ws(self):
        # ws = self.start_websocket_thread()
        self.t_ws = threading.Thread(target=self.start_websocket_thread)
        self.t_ws.start()

    def disconnect_ws(self):
        self.t_ws.join()
        print('4.3')

    def load_cache(self, pmt_url, http_url, ws_url, user, password):
        self.ui.input_url.setText(http_url)
        self.ui.input_user.setText(user)
        self.ui.input_password.setText(password)
