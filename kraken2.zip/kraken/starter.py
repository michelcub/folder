# -*- coding: utf-8 -*-

"""
author: Rodrigo Medinilla
company: PipelinePro Software S.L.
date: 2023/08/09
"""

from PyQt5.QtWidgets import QApplication
import sys

from src.kraken import Kraken


if __name__ == "__main__":
    app = QApplication(sys.argv)
    mi_app = Kraken()
    mi_app.ui.show()
    sys.exit(app.exec_())