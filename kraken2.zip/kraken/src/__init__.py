# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/01
"""
