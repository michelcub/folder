# -*- coding: utf-8 -*-
from PyQt5.QtCore import pyqtSignal

import json
# import asyncio
# import websockets

import websocket
import time

from src.operations.orders import open_folder, download_folder, open_file, frompath_tojson


class WS_comunications():
    def start_websocket_thread(self):
        if 'http:' in self.http_url:
            protocol = 'ws://'
        else:
            protocol = 'wss://'
        #if self.apiKey:
        #    room = self.apiKey
        #else:
        #    room = self.userKey

        room = self.userKey
        url = protocol + self.ws_url + '/ws/kraken/' + room + '/'
        print(url)
        print(f"room {room}")
        self.conexion_activa = True

        self.conexion_activa = True

        try:
            ws = websocket.WebSocketApp(url,
                                        on_open=self.on_open,
                                        on_message=self.on_message,
                                        on_error=self.on_error,
                                        on_close=self.on_close)
            self.ws = ws
            ws.run_forever()
        except Exception as e:
            print("Error al intentar conectar:", e)
            self.reconnect()

    def reconnect(self):
        print("Intentando reconectar...")
        self.print_console_ws.emit('    Intentando reconectar...')
        time.sleep(5)  # Espera antes de intentar la reconexión
        self.start_websocket_thread()

    def on_message(self, ws, message):


        diccionario = json.loads(message)
        if 'order' in diccionario:
            print("Mensaje recibido:", diccionario['message'])
            self.order_class(ws, diccionario)
        else:
            print("Received message without 'order' key:", message)

        if 'message' in diccionario:
            if isinstance(diccionario['message'], dict):
                message = diccionario['message']
                if 'order' in message:
                    self.order_class(ws, message)



    def on_error(self, ws, error):
        print("Error en WebSocket:", error)
        self.reconnect()

    def on_close(self, ws, close_status_code, close_msg):
        print("WS closed")
        self.reconnect()


    def on_open(self, ws):
        self.print_console_ws.emit('    WS Connection OK')
        print("Opened connection")

    def order_class(self, ws, response):
        print(f"response {response}")
        order = response['order']
        if order == 'open_folder':
            path = response['folderLocal']
            open_folder(path)
            self.print_console_ws.emit('    Open Folder: ' + str(path))
        elif order == 'download_folder':
            key = response['key']
            download_folder(self, key)
            self.print_console_ws.emit('    Download Folder: ' + str(key))
        elif order == 'open_file':
            key = response['key']
            fileLocal = open_file(self, key)
            self.print_console_ws.emit('    Open File: ' + str(fileLocal))

        elif order == 'ping_room':
            code = response['code']
            print(code)
            self.print_console_ws.emit('    Open code: ' + str(code))
            mensaje = json.dumps({"message": "<<<<<<< Ping Room - " + str(code)})
            ws.send(mensaje)
        elif order == 'frompath_tojson':
            path = response['path']
            print(path)
            self.print_console_ws.emit('    frompath_tojson: ' + str(path))
            frompath_tojson(self, path)

# class WS_comunications2():
#     def start_websocket_thread(self):
#         if 'http:' in self.http_url:
#             protocol = 'ws://'
#         else:
#             protocol = 'wss://'
#         url = protocol + self.ws_url + '/ws/hydra/' + self.userKey + '/'
#         asyncio.new_event_loop().run_until_complete(self.websocket_listener(url))
#
#
#     def test_ws(self, websocket):
#         connection_state = websocket.state
#         if connection_state == websockets.protocol.State.CONNECTING:
#             txt_state = 'WS Conection in process ...'
#         elif connection_state == websockets.protocol.State.OPEN:
#             txt_state = 'WS Conection open and active'
#         elif connection_state == websockets.protocol.State.CLOSING:
#             txt_state = 'WS Conection closing ...'
#         elif connection_state == websockets.protocol.State.CLOSED:
#             txt_state = 'WS Conection closed'
#         self.print_console_ws.emit(txt_state)
#
#
#     async def websocket_listener(self, url):
#         while True:
#             try:
#                 async with websockets.connect(url) as websocket:
#                     self.test_ws(websocket)
#                     self.websocket = websocket
#                     mensaje = json.dumps({"message": "------------ HOLAAAAAAA, soy Kraken 1"})
#                     await websocket.send(mensaje)
#                     while True:
#                         response = await websocket.recv()
#                         # self.print_console_ws.emit(response)
#                         print("Mensaje recibido:", response)
#                         self.order_class(json.loads(response), websocket)
#
#                     # TODO: Si se corta la conexion reconectar
#             except (websockets.exceptions.ConnectionClosedError, websockets.exceptions.ConnectionClosedOK) as e:
#                 print("La conexión se cerró. Intentando reconexión en 5 segundos...")
#                 print('----------------reconectar-----------------')
#                 await asyncio.sleep(5)
#
#
#     def order_class(self, response, websocket):
#         try:
#             order = response['order']
#         except:
#             print('    Test Connection OK')
#             self.print_console_ws.emit('    Test Connection OK')
#             return True
#
#         if order == 'open_folder':
#             path = response['folderLocal']
#             open_folder(path)
#             self.print_console_ws.emit('    Open Folder: ' + str(path))
#         elif order == 'download_folder':
#             key = response['key']
#             download_folder(self, key)
#             self.print_console_ws.emit('    Download Folder: ' + str(key))
#         elif order == 'open_file':
#             key = response['key']
#             fileLocal = open_file(self, key)
#             self.print_console_ws.emit('    Open File: ' + str(fileLocal))
#         elif order == 'ping_room':
#             print(' hay que responder')
#         #     await self.websocket.send(json.dumps({'message': ">>>>>> Ping Room - "}))
#             room = response['room']
#             self.print_console_ws.emit('    Ping Room: ' + str(room))
#             mensaje = json.dumps({"message": ">>>>>> Ping Room - " + str(room)})
#             # websocket.send(mensaje)
#         #
#             # print('Enviar a backend identidad del punto de ejecucion de Kraken')

