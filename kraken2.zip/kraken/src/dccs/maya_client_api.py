# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: 
date: 2023/08/14
"""

import os
import socket
import traceback
import subprocess
import threading

# MAYA SERVER
# to open in maya the socket
# in User.py or in a opened maya session:
#
# import maya.cmds as cmds
# cmds.commandPort(name=":20201", sourceType="python")
#

from PyQt5 import QtCore

class MayaClient(object):

    def __init__(self, 
                 host='127.0.0.1', 
                 port=20201, 
                 buffer_size=4096):
        self.maya_socket = None
        self.host = host
        self.port = port
        self.buffer_size = buffer_size
        self.exe = '"C:/Program Files/Autodesk/Maya2024/bin/maya.exe"'

        self.proc = QtCore.QProcess()

    def open(self, path):
        if path:
            command = self.exe + ' ' + path
            self.path = path
        else:
            command = self.exe
        print(command)

        # os.system(command)
        # subprocess.run(command, shell=True)

        # thread = threading.Thread(target=self.abrir_maya)
        # thread.start()

        # self.proc.start(command)
        self.proc.startDetached(command)

    def abrir_maya(self):
        command = f'{self.exe} {self.path}'
        subprocess.run(command, shell=True)


    def connect(self):
        try:
            self.maya_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.maya_socket.connect((self.host, self.port))

        except ConnectionError:
            traceback.print_exc()
            return False

        return True

    def disconnect(self):
        try:
            self.maya_socket.close()

        except ConnectionError:
            traceback.print_exc()
            return False

        return True

    def send(self, cmd=None):
        try:
            self.maya_socket.sendall(cmd.encode())

        except ConnectionError:
            traceback.print_exc()
            return None

        return self.recv()

    def recv(self):
        try:
            data = self.maya_socket.recv(self.buffer_size)

        except ConnectionError:
            traceback.print_exc()
            return None

        return data.decode().replace('\x00', '')

    """
    DCC COMMANDS
    add commands methods below here
    """

    def new_file(self):
        cmd = "cmds.file(new=True, force=True)"
        return self.send(cmd)

    def create_primitive(self, shape):
        cmd = ""

        if shape == "sphere":
            cmd += "cmds.polySphere()"
        elif shape == "cube":
            cmd += "cmds.polyCube()"
        else:
            print("Invalid shape: {0}".format(shape))
            return None

        result = self.send(cmd)
        return eval(result)

    def translate(self, node, values):
        cmd = "cmds.setAttr('{0}.translate', {1}, {2}, {3})".format(node, *values)

        return self.send(cmd)


if __name__ == "__main__":
    
    maya_client = MayaClient()

    if maya_client.connect():
        print("Connected Successfully")

        # create a new scene
        file_name = maya_client.new_file()
        print(file_name)

        # create a primitive (sphere)
        sphere = maya_client.create_primitive(shape="sphere")
        print(sphere)

        # translate sphere
        maya_client.translate(sphere[0], [0, 10, 0])

        # create a primitive (cube)
        cube = maya_client.create_primitive(shape="cube")
        print(cube)

        if maya_client.disconnect():
            print("Disconnected Successfully")

    else:
        print("Failed to connect")
