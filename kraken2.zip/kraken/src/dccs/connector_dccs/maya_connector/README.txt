#################################################################################################################


INSTALLATION:

1. Open "userSetup.py" and change the path to pointing on your maya_connector folder
2. Copy "userSetup.py" in your Maya Documents folder.
   For example, in WINDOWS should be:
   		C:\Users\<username>\Documents\maya\<version>\scripts
3. Open Maya and you should see the menu in your Main Menu bar


#################################################################################################################


"maya_command_port.py"
It is the DCC connector that run the server and open the port inside the dcc.


#################################################################################################################


"create_main_menu.py"
It is the file that you need pass each time you run the dcc as external process.
For example:
software_path = "C:\Program Files\Autodesk\Maya2020\bin\maya.exe"
python_script = "create_main_menu.py"
encoded_python = base64.b64encode(python_script.encode('utf-8'))
# use exec cmd instead of execfile cmd for python 3 or >
script_text = '''python("import base64; exec(open(base64.urlsafe_b64decode({})).read())")'''
# command arguments
args = [
	software_path, 
	"-command",    
    script_text.format(encoded_python)
]
# run batch process and hide all output that are not logged by the tool
# (for example, maya batch output line)
subprocess.check_output(args, stderr=subprocess.STDOUT)


#################################################################################################################


"maya_client.py"
It is the client that set the connection with dcc and send commands to the dcc and run some operation.
For example, open new file, save new file, etc. etc.


#################################################################################################################
