# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/21
"""

import os
import sys
sys.path.insert(0, "C:/python/python37/Lib/site-packages")
sys.path.insert(0, "C:/Users/frasu/Downloads/pipelinepro_connector_dccs")

from PySide2 import QtWidgets, QtCore, QtGui

from server_base import ServerBase

import unreal


class CommandPortWindow(QtWidgets.QDialog):

    # store ref to window to prevent garbage collection
    window = None

    def __init__(self, parent):
        super(CommandPortWindow, self).__init__(parent)

        self.server = UnrealServer(parent=parent)

        # init ui
        self.init_ui()
        self.setup_ui()

        # Close pop-up after 2 seconds (2000 ms)
        QtCore.QTimer.singleShot(2000, self.close)

    def init_ui(self):
        self.main_widget = QtWidgets.QWidget()

        main_layout = QtWidgets.QVBoxLayout()

        # create logo image
        logo_pixmap = QtGui.QPixmap("{}/{}".format(
            "C:/Users/frasu/Downloads/pipelinepro_connector_dccs",
            "pipeline_pro_logo.png"
        ))
        self.logo_image = QtWidgets.QLabel()
        self.logo_image.setPixmap(logo_pixmap)
        self.logo_image.setFixedSize(logo_pixmap.size().width(),
                                     logo_pixmap.size().height())
        self.logo_image.setAlignment(QtCore.Qt.AlignCenter)

        # create label for connection status
        self.connection_status = QtWidgets.QLabel()
        self.connection_status.setAlignment(QtCore.Qt.AlignCenter)
        self.connection_status.setStyleSheet("color: rgb(255, 255, 255);"
                                             "font-weight: thin;"
                                             "font-size:16px")

        main_layout.addWidget(self.logo_image)
        main_layout.addWidget(self.connection_status)

        self.main_widget.setParent(self)
        self.main_widget.setLayout(main_layout)

        self.setFixedSize(400, 200)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint |
                            QtCore.Qt.WindowStaysOnTopHint |
                            QtCore.Qt.Dialog)
        self.setWindowOpacity(1)
        self.setStyleSheet("background-color: rgb(25, 35, 45);")
        self.center_window_position()
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)

    def setup_ui(self):
        try:
            self.connection_status.setText(self.server.get_msg_status())
        except Exception as e:
            print("{}".format(str(e)))

    def center_window_position(self):
        """
        center window on screen
        :return:
        """
        qr = self.frameGeometry()
        cp = QtGui.QGuiApplication.primaryScreen().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())


class UnrealServer(ServerBase):

    PORT = 17562

    def __init__(self, port=None, parent=None):
        super(UnrealServer, self).__init__(port, parent)

    def process_cmd(self, cmd, data, reply):
        if cmd == "open":
            self.open(data, reply)
        elif cmd == "save":
            self.save(data, reply)
        else:
            super(UnrealServer, self).process_cmd(cmd, data, reply)

    def open(self, data, reply):
        file_path = data["file_path"]

        result = None

        reply["result"] = result
        reply["success"] = True

    def save(self, data, reply):
        """
        save file. If new_file flag is True, save new file.
        """
        file_path = data["file_path"]
        is_new_file = data["new_file"]
        file_type = data["file_type"]
        
        result = None

        reply["result"] = result
        reply["success"] = True


def main():

    if QtWidgets.QApplication.instance():
        # Id any current instances of tool and destroy
        for win in (QtWidgets.QApplication.allWindows()):
            if 'PipelineProCommandPort' in win.objectName(): # update this name to match name below
                win.destroy()
    else:
        QtWidgets.QApplication(sys.argv)
    
    # load UI into QApp instance
    CommandPortWindow.window = CommandPortWindow(parent=None)
    CommandPortWindow.window.show()
    CommandPortWindow.window.setObjectName('PipelineProCommandPort') # update this with something unique to your tool
    unreal.parent_external_window_to_slate(CommandPortWindow.window.winId())
