import sys
sys.path.insert(0, "C:/Users/frasu/Downloads/pipelinepro_connector_dccs/unreal_connector")

import create_main_menu
create_main_menu.create_pipelinepro_menu(menu_name='PipelinePro')

import unreal_command_port
unreal_command_port.main()