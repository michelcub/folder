import unreal



def create_pipelinepro_menu(menu_name):
    menus = unreal.ToolMenus.get()
    # get main menu
    main_menu = menus.find_menu("LevelEditor.MainMenu")

    if not main_menu:
        print("Failed to find the 'Main' menu. Something is wrong in the force!")

    entry = unreal.ToolMenuEntry(
                                name="Command.Port",
                                type=unreal.MultiBlockType.MENU_ENTRY,
                                insert_position=unreal.ToolMenuInsert("", unreal.ToolMenuInsertType.FIRST)
    )

    entry.set_label("Command Port")

    command_str = "import sys;sys.path.insert(0, \"C:/Users/frasu/Downloads/pipelinepro_connector_dccs/unreal_connector\");import unreal_command_port;unreal_command_port.main();"
    entry.set_string_command(type=unreal.ToolMenuStringCommandType.PYTHON, custom_type= unreal.Name(""), string=command_str)

    # add a new menu called PipelinePro to the MainMenu bar
    script_menu = main_menu.add_sub_menu(main_menu.get_name(), menu_name, menu_name, menu_name)

    # add our new entry to the new m
    script_menu.add_menu_entry("Scripts", entry)

    # refresh the UI
    menus.refresh_all_widgets()


if __name__ == "__main__":
    create_pipelinepro_menu(menu_name="PipelinePro")