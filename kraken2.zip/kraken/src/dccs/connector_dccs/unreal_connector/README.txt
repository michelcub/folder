#################################################################################################################


INSTALLATION:
(documentation: https://docs.unrealengine.com/4.26/en-US/ProductionPipelines/ScriptingAndAutomation/Python/#theinit_unreal.pyfile)


1. Copy the content of "init_unreal.py" file in your local init_unreal.py file. If you don't have this file you can create it.
   Save it in one of local Python folder, for example:
   	WINDOWS
   		The Unreal Editor automatically adds several paths to this sys.path list:
		The Content/Python sub-folder under your Project's folder.
		The Content/Python sub-folder in the main Unreal Engine installation.
		The Content/Python sub-folder under each enabled Plugin's folder.
		The Documents/UnrealEngine/Python folder inside your user directory. For example, on Windows 10, this is equivalent to 
		C:/Users/<username>/Documents/UnrealEngine/Python

2. Change the path inside "init_unreal.py" to load the correct path that contains "create_main_menu.py"
2a. "init_unreal.py" also will execute the command port automatically


#################################################################################################################


"unreal_command_port.py"
It is the DCC connector that run the server and open the port inside the dcc.


#################################################################################################################


"init_unreal.py" and "create_main_menu.py"
These files are in charge to create the menu in the top menu bar.
"create_main_menu.py" contains the code to create the menu and "init_unreal.py" is the file that we need to install 
in user local documents folder to load at startup the menu.
For example, in windows the C:/Users/Username/Documents/UnrealEngine/Python folder is the best solution to 
share the code for every project.


#################################################################################################################


"unreal_client.py"
It is the client that set the connection with dcc and send commands to the dcc and run some operation.
For example, open new file, save new file, etc. etc.


#################################################################################################################
