# -*- coding: utf-8 -*-

"""
author: Francesco Surace
company: PipelinePro Software S.L.
date: 2023/08/21
"""

import sys
sys.path.insert(0, "C:/Users/frasu/Downloads/pipelinepro_connector_dccs")

from client_base import ClientBase


class HoudiniClient(ClientBase):

    PORT = 17560

    def open(self, file_path):
        cmd = {
            "cmd": "open",
            "file_path": file_path,
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None

    def save(self, file_path, is_new_file=False, file_type="hip"):
        cmd = {
            "cmd": "save",
            "file_path": file_path,
            "new_file": is_new_file,
            "file_type": file_type
        }

        reply = self.send(cmd)

        if self.is_valid_reply(reply):
            return reply["result"]
        else:
            return None


if __name__ == "__main__":

    file_path = "C:/Users/frasu/Desktop/cube.hipnc"

    houdini_client = HoudiniClient(timeout=120)
    if houdini_client.connect():
        print("Connected successfully.")

        # open
        result = houdini_client.open(file_path)
        if result:
            print("File opened successfully: '{0}'".format(result))


        # file_path = "C:/Users/frasu/Desktop/cube_3.hipnc"
        # # save same file
        # result = houdini_client.save(file_path)
        # print(result)
        # if result:
        #    print("File saved successfully: '{0}'".format(result))

        # save as new version
        # new_file_path = "C:/Users/frasu/Desktop/cube_2.hipnc"
        # result = houdini_client.save(new_file_path, is_new_file=True)
        # if result:
        #    print("File saved successfully: '{0}'".format(result))

        if houdini_client.disconnect():
            print("Disconnected successfully")

    else:
        print("Failed to connect")
