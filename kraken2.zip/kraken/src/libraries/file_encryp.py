# -*- coding: utf-8 -*-

import os
import pickle
import base64
import random

from src.api.graphql import loging

def save_disk(file_disk, data):
    file = open(file_disk, 'wb')
    pickle.dump(data, file)
    file.close()
    return True


def load_disk(file_disk):
    # try:
    file = open(file_disk, 'rb')
    data = pickle.load(file)
    file.close()
    # except:
    #     data = None
    return data


def encrypt(code):
    pre_random = str(random.randint(1000, 9999))
    post_random = str(random.randint(1000, 9999))
    message = pre_random + '-' + code + '-' + post_random
    message_bytes = message.encode('ascii')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('ascii')

    return base64_message


def deencrypt(cript):
    base64_bytes = cript.encode('ascii')
    message_bytes = base64.b64decode(base64_bytes)
    message = message_bytes.decode('ascii')

    code = message[5:]
    code = code[:-5]
    return code


def read_cache_file(file_disk):
    """
    Se lee el fichero y se le carga el contenido al objeto. Si no es legible se ignora
    """
    try:
        data = load_disk(file_disk)
        if data and data['pmt_url']:
            pmt_url = data['pmt_url']
            http_url = pmt_url.rstrip('/')
            ws_url = http_url.replace('https://', '')
            ws_url = ws_url.replace('http://', '')
            user = deencrypt(data['user'])
            password = deencrypt(data['password'])

        return pmt_url, http_url, ws_url, user, password
    except:
        os.remove(file_disk)
        return False



def write_cache_file(file_disk, pmt_url, user, password):
    data = {
        'pmt_url': pmt_url,
        'user': encrypt(user),
        'password': encrypt(password),
    }
    save_disk(file_disk, data)