import os
import json
import re
from collections import defaultdict


def find_sequences(folder_route):
    sequences = defaultdict(list)
    for root, folders, files in os.walk(folder_route):
        for file in files:
            coincidence = re.match(r"(.*?)(\d+)(\.\w+)$", file)
            if coincidence:
                prefix, number, extension = coincidence.groups()
                route = os.path.join(root, file)
                sequences[prefix, extension].append((int(number), route))

    compressed_sequences = []
    for (prefix, extension), files in sequences.items():
        if len(files) < 2:
            continue
        files.sort()
        init = files[0][0]
        end = files[-1][0]
        increment = files[1][0] - files[0][0]
        padding = len(str(files[0][0]))

        compressed_sequences.append({
            "Route": os.path.join(folder_route, f"{prefix}[{'#' * padding}]"),
            "Core_name": f"{prefix}[{'#' * padding}]{extension}",
            "Extension": extension,
            "Init": init,
            "End": end,
            "Increment": increment,
            "padding": padding
        })

    return compressed_sequences


def obtener_informacion_ruta(ruta):

    if not os.path.exists(ruta):
        return {"error": "La ruta no existe"}

    informacion_ruta = {
        "nombre": os.path.basename(ruta),
        "tipo": "directorio" if os.path.isdir(ruta) else "archivo"
    }

    if informacion_ruta["tipo"] == "directorio":
        informacion_ruta["contenido"] = []
        informacion_ruta["route"] = ruta.replace("\\", "/")
        contenido_directorio = os.listdir(ruta)
        tiene_secuencias = any(re.match(r"(.*?)([0-9]+)(\.\w+)$", archivo) for archivo in contenido_directorio)
        if tiene_secuencias:
            informacion_ruta["sequences"] = find_sequences(ruta)  # Recopila secuencias solo si tiene
        for elemento_nombre in contenido_directorio:
            elemento_ruta = os.path.join(ruta, elemento_nombre)
            informacion_elemento = obtener_informacion_ruta(elemento_ruta)
            informacion_ruta["contenido"].append(informacion_elemento)

    elif informacion_ruta["tipo"] == "archivo":
        informacion_ruta["size"] = os.path.getsize(ruta)
        informacion_ruta["route"] = ruta.replace("\\", "/")

    return informacion_ruta


# Ruta inicial que deseas explorar
# ruta_inicial = "C:/Users/michel/Downloads/ADA_101/ADA_101/010/1010/Event__0007_0004"  # Reemplaza esto con la ruta que deseas explorar
# ruta_inicial = "C:/Users/michel/Downloads/ADA_101/"
#
# informacion_ruta_inicial = json.dumps(obtener_informacion_ruta(ruta_inicial))



