# -*- coding: utf-8 -*-

from PyQt5.QtCore import QObject, pyqtSignal

import urllib.parse
import urllib.request
import ctypes
import json
import threading
from queue import Queue
import requests
from PIL import Image

# import ffmpeg
# import moviepy.editor
from moviepy.editor import *
import cv2


from src.operations.validation import validate_apiKey



global errors_list
errors_list = 0

class Hydra(QObject):
    """
    Este es el objeto que controla las tareas de control de ficheros
    """
    print_console_hydra = pyqtSignal(str)

    def __init__(self, key, http_url):
        super(Hydra, self).__init__()
        self.key = key
        self.http_url = http_url
        self.version = 215
        self.version = '2023.2.1'
        # ready = self.connect()
        if ready:
            self.initialize_work_folders()
            self.print_lock = threading.Lock()
            self.q = Queue()
            self.q_up = Queue()

            self.thread_amount = 10

            print('Kraken Iniciada')
            print('Project Connect:', self.project_name if self.project_name else 'xxx')

    def initialize_work_folders(self):
        # initializa las carpetas temporales y de descarga final para poder operar
        try:
            os.makedirs(self.tempFolder)
            # self.print_console_hydra.emit(' Created temp Folder', self.tempFolder)
            # print(' Created temp Folder', self.tempFolder)
        except:
            pass

        try:
            os.makedirs(self.workFolder)
            print(' Created work Folder', self.workFolder)
        except:
            pass
        return self.tempFolder, self.workFolder



    def api_call(self, query):
        # if self.token:
        #     query = query.replace('{token}', self.token)
        response = requests.post(self.http_url + '/graphql/', json={'query': query})
        return response.text

    # def loging(self):
    #     query_token = f'''
    #           mutation {{
    #             tokenAuth(username: "{self.username}", password: "{self.password}") {{
    #               token
    #             }}
    #           }}
    #         '''
    #     response_token = self.api_call(query_token)
    #     response_token = json.loads(response_token)
    #     token_auth = response_token['data']['tokenAuth']['token']
    #     return token_auth


    def connect(self):
        api_response = None
        query_connect = '''
                      {
                        apikeyAuth(key: "{key}") {
                            key
                            code
                            name
                            folderName
                        }
                      }
                    '''
        query_connect = query_connect.replace('{key}', self.key)
        try:
            # api_response = self.api_call({'key': self.key}, self.http_url + '/rest/hydra_key/')
            api_response = self.api_call(query_connect)
            apiKey = json.loads(api_response)
            apiKey = apiKey['data']['apikeyAuth']
        except:
            print('  ERROR: Connection fail to server')
            self.print_console_hydra.emit('  Error Validando apikey')

        if not api_response:
            print('   Desconectar y pedir nuevas credenciales')
            self.print_console_hydra.emit('  NO Connected to Server')
            return False
        else:
            self.urlpmt = self.http_url + '/rest/sync_dependence_download/'
            self.urlbase = self.http_url + '/media/project/'

            # TODO: En poco no será necesario al darlo a API
            # self.tkn_file = apiKey["tkn_file"]
            # self.user_folder_sync = apiKey["user_folder_sync"]
            # self.filetxt_TKN = self.urlbase + self.user_folder_sync + self.tkn_file

            self.project_name = apiKey["name"]
            self.project_code = apiKey["code"]
            self.project_key = apiKey["key"]
            self.project_folderName = apiKey["folderName"]

            # local Hydra work Folders
            self.tempFolder = 'C:/Kraken/temp/'
            self.workFolder = 'C:/Kraken/'
            # self.workFolder = apiKey["storage_project_local_folder"] if apiKey["storage_project_local_folder"] else 'C:/Hydra/'

            # self.pathRoot_local = self.workFolder
            # self.pathRoot_cloud = 'project/' + apiKey["project_key"]
            self.print_console_hydra.emit('  Connected to ' + self.project_name)

            return True


        # ========================================================

    def disk_space(self):
        free_bytes = ctypes.c_ulonglong(0)
        ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p(self.workFolder), None, None, ctypes.pointer(free_bytes))
        freeDisk = free_bytes.value / 1024 / 1024
        return freeDisk


    def process(self, data):
        # Entrada de proceso de linea desde el Json
        print('    data:', data)
        data = json.loads(data)

        content = data['content']
        command = data['content']['message']
        print('    command:', command)
        print('th_a: ', threading.active_count())

        command_list = command.split('\rn')
        for command in command_list:
            print('   command line:', command)
            # TODO: Quitar espacios vacios
            if command.split('/')[0] == 'DOWNLOAD_ALL_PROJECT.':
                print('... DOWNLOAD_ALL_PROJECT ...')
                self.print_console_hydra.emit('      Download all project ' + self.project_name)
                download_main_path = command.replace('DOWNLOAD_ALL_PROJECT./', '')
                self.main_download_all(download_main_path)

            elif command.split('/')[0] == 'SEEK_FOLDER.':
                print('... Look Folder ...')
                download_main_path = command.replace('SEEK_FOLDER./', '')
                full_path = download_main_path.replace('\\', '/')
                file_list = os.listdir(full_path)
                # print(full_path)
                # print(file_list)
                json_response = json.dumps(file_list)
                self.print_console_hydra.emit(json_response)

                return file_list

                # self.print_console_hydra.emit(download_main_path)
                # self.print_console_hydra.emit('    Look folder: ' + str(download_main_path))
            elif command.split('/')[0] == 'IMPORT_EPISODE.':
                print('... Look Folder from import ...')
                download_main_path = command.replace('IMPORT_EPISODE./', '')
                full_path = download_main_path.replace('\\', '/')
                file_list = os.listdir(full_path)

                shot_list = []
                shot_id = 10
                in_frame = 0
                out_frame = 0
                for file in file_list:
                    media_file = full_path + file
                    if not os.path.isfile(media_file):
                        continue
                    file_extension = file.split('.')[-1:][0]
                    if file_extension in ['mov', 'avi', 'mp4']:

                        video = cv2.VideoCapture(media_file)
                        video_duration = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
                        video_fps = video.get(cv2.CAP_PROP_FPS)

                        step_frame = 10

                        in_frame = in_frame
                        out_frame = in_frame + int(video_duration)

                        shot = {
                            'shot_number': shot_id,
                            'duration': video_duration,
                            'framerate': video_fps,
                            'in_frame': in_frame,
                            'out_frame': out_frame,
                            'extension': file_extension,
                            'filename': file
                        }
                        shot_id += step_frame
                        in_frame += video_duration

                        shot_list.append(shot)
                json_response = json.dumps(shot_list)

                console_text = 'Send ' + str(len(file_list)) + ' shots. ' + str(out_frame) + ' frames'
                self.print_console_hydra.emit(console_text)

                return json_response

            elif command.split('/')[0] == 'UPLOAD_EPISODE.':
                episode_code = content['episode_code']
                project_key = content['project_key']

                print('... Convert and upload ALL ...')
                self.print_console_hydra.emit('      Convert and upload ALL ep' + episode_code)
                download_main_path = command.replace('UPLOAD_EPISODE./', '')
                self.main_upload_episode_all(download_main_path, episode_code)


            # elif command.split('/')[0] == 'LINK.':
            else:
                file_lines = []

                # file_lines.append(command)
                # self.process_file_tkn(file_lines)
                # for line in command:
                #     file_lines.append(line.rstrip('\r\n'))
                task_key = command.replace('LINK./', '')
                if task_key:
                    file_lines_api = self.hydra_api_task(task_key)
                    file_lines = json.loads(file_lines_api)
                    file_lines = list(file_lines['files_hydra'])
                    print('    file_lines:', file_lines)
                    self.process_file_tkn(file_lines)


                # file_lines_api = self.hydra_api_folder(data['folder_key'])
                # file_lines = json.loads(file_lines_api)
                # file_lines = list(file_lines['files_hydra'])
                # print('    file_lines:', file_lines)
                # self.process_file_tkn(file_lines)
            # else:
            #     self.process_file_tkn(command)



    # ===================  MAIN UPLOAD EPISODE
    def main_upload_episode_all(self, download_main_path, episode_code):
        full_path = download_main_path.replace('\\', '/')
        file_list = os.listdir(full_path)

        if threading.active_count() < 20:
            self.threader_up(amount=20, threader_type='threader_upload_episode')
        shot_number = 0
        for file in file_list:
            media_file = full_path + file
            if not os.path.isfile(media_file):
                continue
            file_extension = file.split('.')[-1:][0]
            if file_extension in ['mov', 'avi', 'mp4']:
                shot_number += 10
                job = {
                    'full_path': full_path,
                    'file': file,
                    'episode_code': episode_code,
                    'shot_number': shot_number,
                }
                self.q_up.put(job)
        self.q_up.join()
        self.print_console_hydra.emit('Upload completed Episode')


    def save_image_from_video(self, media_file):
        # try:
        image_name = media_file + '.jpg'

        clip = VideoFileClip(media_file)
        clip.save_frame(image_name, t=0.5)
        clip.reader.close()

        reSizeImageWebp(image_name)
        # except:
        #     return False

    def compress_video(self, media_file):
        video = cv2.VideoCapture(media_file)
        frame_width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
        frame_height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
        video2 = cv2.VideoWriter(media_file + '.mp4', cv2.VideoWriter_fourcc(*'X264'), int(video.get(cv2.CAP_PROP_FPS)), (frame_width, frame_height))
        while True:
            has_frame, frame = video.read()
            if not has_frame:
                print('Can\'t get frame')
                break

            video2.write(frame)

            cv2.imshow('frame', frame)
            key = cv2.waitKey(3)
            if key == 27:
                print('Pressed Esc')
                break

        video.release()
        video2.release()
        cv2.destroyAllWindows()




    def hydra_api_folder(self, folder_key):
        data = {
            'folder_key': folder_key,
        }
        endpoint = self.http_url + '/files/hydra_api_folder/'
        response = requests.post(endpoint, data).content

        return response

    def hydra_api_task(self, task_key):
        data = {
            'task_key': task_key,
        }
        endpoint = self.http_url + '/files/hydra_api_folder/'
        response = requests.post(endpoint, data).content

        return response

    # TODO: Clear
    def process_file_tkn(self, file_lines):
        """
        Ya no es necesario porque se pide a la API
        """
        print('th_b: ', threading.active_count())
        for filePath_Dream in file_lines:
            if filePath_Dream.split('/')[0] == 'LINK.':
                localLinkFiles = filePath_Dream.replace('LINK.', '')
                self.readFileList(localLinkFiles)
            elif filePath_Dream.split('/')[0] == 'FOLDER.':
                try:
                    localfolderFiles = self.workFolder + filePath_Dream
                    localfolderFiles = localfolderFiles.replace('FOLDER.', '')
                    os.makedirs(localfolderFiles)
                except:
                    pass
            else:
                # Mete el fichero a la cola de descarga
                # -- DOWNLOAD
                if file_lines and threading.active_count() < self.thread_amount:
                    self.threader_up(amount=self.thread_amount - threading.active_count())
                # print('    filePath_Dream:', filePath_Dream)
                self.q.put(filePath_Dream)

        self.q.join()

    # TODO: Clear
    def readFileList(self, fileName):
        """
        Ya no es necesario porque se pide a la API
        """
        # Lectura de fichero de dependencias y construccion de la lista
        filetxt_XL_new = self.urlbase + self.user_folder_sync + fileName
        response = urllib.request.urlopen(filetxt_XL_new)
        f_lines = []

        for line in response:
            line = line.decode("utf-8")
            f_lines.append(line.rstrip('\r\n'))

        for filePath_Dream in f_lines:
            if '$' in filePath_Dream:
                # Errores raros
                pass
            elif filePath_Dream.split('/')[0] == 'LINK.':
                localLinkFiles = filePath_Dream.replace('LINK.', '')
                self.readFileList(localLinkFiles)
            elif filePath_Dream.split('/')[0] == 'FOLDER.':
                try:
                    localfolderFiles = self.workFolder + filePath_Dream
                    localfolderFiles = localfolderFiles.replace('FOLDER.', '')
                    os.makedirs(localfolderFiles)
                except:
                    pass
            else:
                # Mete el fichero a la cola de descarga
                # -- DOWNLOAD
                if f_lines and threading.active_count() < self.thread_amount:
                    self.threader_up(amount=self.thread_amount - threading.active_count())
                self.q.put(filePath_Dream)



    # -------------------- INICIADOR THREADS -------------------
    def threader_up(self, amount=20, threader_type='threader_download'):
        print(' Hilos Activos', threading.active_count())
        for x in range(amount):
            if threader_type == 'threader_upload':
                t = threading.Thread(target=self.threader_upload)
            elif threader_type == 'threader_upload_episode':
                t = threading.Thread(target=self.threader_upload_episode)
            else:
                t = threading.Thread(target=self.threader_download)
                # print(t.name)
            t.daemon = True
            t.start()
        print(' Hilos Activos', threading.active_count())
    # ----------------------------------------------------------


    # ----------------------- DOWNLOAD TH ----------------------
    def threader_download(self):
        while True:
            filePath_Dream = self.q.get()
            self.execute_download_Job(filePath_Dream)
            self.q.task_done()

    def execute_log_Job(self, filePath_Dream):
        pass
        with self.print_lock:
            print(threading.current_thread().name, filePath_Dream)
            pass

    def execute_download_Job(self, filePath_Dream):
        global errors_list
        filepath_from = self.path_local_to_cloud(filePath_Dream)
        filepath_to = self.path_cloud_to_local(filePath_Dream)

        # print('    filepath_from:', filepath_from)
        # print('    filepath_to:', filepath_to)
        filepath_to_folder = os.path.dirname(filepath_to)
        # print('    filepath_to_folder:', filepath_to_folder)

        filePath_Dream_NO = filepath_from.split('____')[0]
        filepath_to = self.path_cloud_to_local(filePath_Dream_NO)

        if not os.path.isdir(filepath_to_folder):
            print('    Folder created')
            os.makedirs(filepath_to_folder)

        if not os.path.exists(filepath_to):
            if self.file_exist_in_S3(filePath_Dream):
                try:
                    self.s3.download_file(self.storage_bucket_name, filepath_from, filepath_to,
                                     Callback=ProgressPercentage_download(self.s3, self.storage_bucket_name, filepath_from, self.print_console_hydra))
                except:
                    errors_list += 1
                    print('  ERROR: Download file', filePath_Dream)
        self._running = False
        with self.print_lock:
            self.print_console_hydra.emit('      Downloaded --> ' + str(filepath_to))
            # threading.current_thread().stop
            # print(threading.current_thread().name, filepath_to)
            pass
    # ----------------------------------------------------------

    # ------------------------ UPLOAD TH -----------------------
    def threader_upload(self):
        while True:
            filepath_local = self.q_up.get()
            self.execute_upload_Job(filepath_local)
            self.q_up.task_done()

    def execute_upload_Job(self, filePath_Dream):
        global errors_list
        filepath_to = self.path_local_to_cloud(filePath_Dream)
        filepath_from = self.path_cloud_to_local(filePath_Dream)

        # filepath_to_folder = os.path.dirname(filepath_to)

        filePath_Dream_NO = filepath_from.split('____')[0]
        filepath_to = self.path_cloud_to_local(filePath_Dream_NO)

        # response = s3.upload_file(file_path, bucket_name, key_name, Callback=ProgressPercentage_upload(file_path))
        if not os.path.exists(filepath_to):
            if self.file_exist_in_S3(filePath_Dream):
                try:
                    self.s3.upload_file(filepath_from, self.storage_bucket_name, filepath_from, filepath_to, Callback=ProgressPercentage_upload(filepath_from))
                except:
                    errors_list += 1
                    print('  ERROR: Upload file', filePath_Dream)
        self._running = False
        with self.print_lock:
            self.print_console_hydra.emit('      Uploaded --> ' + str(filepath_to))
            # threading.current_thread().stop
            # print(threading.current_thread().name, filepath_to)
            pass
    # ----------------------------------------------------------

    # ------------------------ UPLOAD EPISODE ------------------
    def threader_upload_episode(self):
        while True:
            job = self.q_up.get()
            self.threader_upload_episode_Job(job)
            self.q_up.task_done()

    def threader_upload_episode_Job(self, job):
        global errors_list

        episode_code = job['episode_code']
        shot_number = job['shot_number']
        full_path = job['full_path']
        file = job['file']

        media_file = full_path + file

        # Crear captura y compresion a webp
        image_process = self.save_image_from_video(media_file)
        if not image_process:
            self.save_image_from_video(media_file)

        # Compresion de video a mp4
        # self.compress_video(media_file)

        folder_S3 = 'project/' + self.project_key + '/' + self.project_folderName + '/2_PROD/ep' + \
                    str(episode_code) + '/sh' + str(shot_number).zfill(4) + '_0/0_Briefing/'

        file_terminals = ['', '.jpg', '.jpg_L.webp', '.jpg_M.webp', '.jpg_S.webp', '.jpg_XS.webp', '.jpg_XXS.webp']
        for terminal in file_terminals:
            filepath_from = media_file + terminal
            try:
                if not os.path.isfile(filepath_from):
                    continue
            except:
                continue

            # ----- S3


            if os.path.exists(filepath_from):
                filepath_to = folder_S3 + file + terminal
                # print(filepath_from)
                # print(filepath_to)
                # if self.file_exist_in_S3(filepath_to):
                try:
                    self.s3.upload_file(filepath_from, self.storage_bucket_name, filepath_to, ExtraArgs={'ACL': ''})
                except Exception as e:
                    print(e)
                    errors_list += 1
                    print('  ERROR: Upload file', filepath_from)


            # filepath_to = folder_S3 + file + terminal
            # self.s3.upload_file(filepath_from, self.storage_bucket_name, filepath_to, Callback=ProgressPercentage_upload(filepath_from))

            # ----- Local
            # filepath_to = 'C:/Users/medinilla/Dropbox/Medinilla/PPL_PipelinePro/P5_DEV_DESARROLLO/PipelinePro/pipelinepro/media/' + folder_S3 + file + terminal
            # dst_Folder = os.path.dirname(filepath_to)
            # if not os.path.isdir(dst_Folder):
            #     os.makedirs(dst_Folder)
            # shutil.copyfile(filepath_from, filepath_to)

            self.print_console_hydra.emit('        Uploaded ' + filepath_from)

        file_terminals = ['.jpg', '.jpg_L.webp', '.jpg_M.webp', '.jpg_S.webp', '.jpg_XS.webp', '.jpg_XXS.webp']
        for terminal in file_terminals:
            filepath_from = media_file + terminal
            try:
                if not os.path.isfile(filepath_from):
                    continue
            except:
                continue
            os.remove(filepath_from)

        self._running = False
        with self.print_lock:
            self.print_console_hydra.emit('    Uploaded all ' + str(file))
            # threading.current_thread().stop
            # print(threading.current_thread().name, filepath_to)
            pass
    # ----------------------------------------------------------


    # ===================  MAIN DOWNLOAD
    def main_download_all(self, download_main_path):
        if threading.active_count() < self.thread_amount:
            self.threader_up(amount=self.thread_amount - threading.active_count())
        file_list = self.list_bucket_files(self.storage_bucket_name, main_path=download_main_path)
        for file in file_list:
            filePath_Dream = file.replace('project/' + self.project_key, '')
            if self.include:
                for expresion_in in self.include.split(','):
                    if expresion_in in file:
                        self.q.put(filePath_Dream)
            else:
                self.q.put(filePath_Dream)
        self.q.join()
        self.print_console_hydra.emit('  Download completed of ' + self.project_name)

    def file_exist_in_S3(self, filePath_Dream):
        path_cloud = self.path_local_to_cloud(filePath_Dream)
        try:
            obj = self.s3.head_object(Bucket=self.storage_bucket_name, Key=path_cloud)
            print('   File Size: ' + str(obj['ContentLength']))
            return obj['ContentLength']
        except self.s3 as exc:
            if exc.response['Error']['Code'] != '404':
                print('  ERROR 404: File not in S3', self.storage_bucket_name, path_cloud)
                raise
            print('  ERROR: File not in S3', self.storage_bucket_name, path_cloud)
            return False

    def path_cloud_to_local(self, path_cloud):
        path_local = path_cloud.replace(self.pathRoot_cloud, '')
        path_local = self.workFolder + path_local
        # print('    Copiar a     --    ' + path_local)

        return path_local

    def path_local_to_cloud(self, path_local):
        path_cloud = path_local.replace(self.workFolder, '')
        path_cloud = self.pathRoot_cloud + path_cloud
        # print('    Recoger de   --    ' + path_cloud)

        return path_cloud

    def list_bucket_files(self, bucket_name, main_path):
        my_bucket = self.r3.Bucket(bucket_name)
        file_list = []
        for file in my_bucket.objects.filter(Prefix=main_path):
            file_list.append(file.key)

        return file_list



class ProgressPercentage_download(object):
    def __init__(self, client, bucket, filename, print_console_hydra):
        self._filename = filename
        self._size = int(client.head_object(Bucket=bucket, Key=filename)['ResponseMetadata']['HTTPHeaders']['content-length'])
        self._seen_so_far = 0
        self._lock = threading.Lock()
        self.print_console_hydra = print_console_hydra

    def __call__(self, bytes_amount):
        # To simplify, assume this is hooked up to a single filename
        with self._lock:
            self._seen_so_far += bytes_amount
            percentage = (self._seen_so_far / self._size) * 100
            sys.stdout.write(
                "\r%s  %s / %s  (%.2f%%)" % (
                    self._filename, self._seen_so_far, self._size,
                    percentage))
            self.print_console_hydra.emit(
                "          %s / %s  (%.2f%%)" % (
                    self._seen_so_far, self._size,
                    percentage))
            sys.stdout.flush()

class ProgressPercentage_upload(object):
    def __init__(self, filename):
        self._filename = filename
        self._size = float(os.path.getsize(filename))
        self._seen_so_far = 0
        self._lock = threading.Lock()

    def __call__(self, bytes_amount):
        # To simplify, assume this is hooked up to a single filename
        with self._lock:
            self._seen_so_far += bytes_amount
            percentage = (self._seen_so_far / self._size) * 100
            sys.stdout.write(
                "\r%s  %s / %s  (%.2f%%)" % (
                    self._filename, self._seen_so_far, self._size,
                    percentage))
            sys.stdout.flush()


#------------------------------ Resize
def reSizeImageWebp(imagePath):
    if not imagePath.split('.')[-1].lower() in ['jpg', 'jpeg', 'png', 'tiff', 'tif', 'tga', 'bmp', 'webp']:
        return False
    im = Image.open(imagePath)

    resolution_list = {
        '_XXS.webp': 60,
        '_XS.webp': 140,
        '_S.webp': 500,
        '_M.webp': 1200,
        '_L.webp': 1920
    }

    for name, sizeX in resolution_list.items():
        imagePath_Out = str(imagePath) + str(name)

        sizeY = int(sizeX * (float(im.height) / float(im.width)))
        im_resized = im.resize((int(sizeX), int(sizeY)))
        im_resized.save(imagePath_Out, format="webp")
    im.close()
